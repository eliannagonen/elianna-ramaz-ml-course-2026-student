"""HW00 — Analysis: Songs Dataset

Implement the pieces below using plain Python: file I/O, a Counter-based
aggregation, and a small class hierarchy for ranking songs. The dataset is
data/songs.csv (open it to see the raw rows). Its columns are:

    title             str    song title
    artist            str    performing artist
    genre             str    e.g. Pop, Rock, Hip-Hop
    year              int    year the song charted
    weeks_on_chart    int    total weeks the song spent on the chart
    peak_position     int    best chart position reached (1 = number one)
    streams_millions  float  total streams, in millions

After completing the functions, run this script to print your results:

    uv run python analysis.py

Use the printed output to answer the questions in writeup.md.
"""

from __future__ import annotations

import csv
from collections import Counter
from pathlib import Path


def load_songs(path: Path) -> list[dict]:
    """Load the songs CSV and return a list of records, one dict per row.

    Casts year, weeks_on_chart, and peak_position to int, and
    streams_millions to float. All other fields stay strings.

    Args:
        path: Path to the songs CSV file.

    Returns:
        A list of dicts, one per song, with the correct field types.

    Example:
        >>> songs = load_songs(Path("data/songs.csv"))
        >>> isinstance(songs[0]["year"], int)
        True
    """
    with open(path, 'r', newline='') as file:
        reader = csv.DictReader(file)

        list_of_records = []

        for row in reader:
            row["year"] = int(row["year"])
            row["weeks_on_chart"] = int(row["weeks_on_chart"])
            row["peak_position"] = int(row["peak_position"])
            row["streams_millions"] = float(row["streams_millions"])

            list_of_records.append(row)

    return list_of_records
        

class SongRanker:
    """Base class for ranking a list of songs by some criterion.

    Subclasses implement score() to define what "best" means; rank() is
    shared logic that works for any scoring rule.
    """

    def score(self, song: dict) -> float:
        """Return the value used to rank this song. Higher is better.

        Subclasses must override this.
        """

        raise NotImplementedError
        


    def rank(self, songs: list[dict], n: int = 10) -> list[dict]:
        """Return the top n songs, highest score() first.

        Args:
            songs: List of song records (as returned by load_songs).
            n: Number of songs to return (default 10).

        Returns:
            A list of the n songs with the highest score(), sorted
            highest-first. Ties may break in any order.

        Example:
            >>> top = StreamsRanker().rank(songs, n=3)
            >>> len(top)
            3
            >>> top[0]["streams_millions"] >= top[1]["streams_millions"]
            True
        """
        ranked_list = sorted(songs, key=self.score, reverse = True)

        return ranked_list[:n]

  

class StreamsRanker(SongRanker):
    """Ranks songs by total streams_millions."""

    def score(self, song: dict) -> float:
        return song['streams_millions']


class LongevityRanker(SongRanker):
    """Ranks songs by weeks_on_chart (how long they stuck around)."""

    def score(self, song: dict) -> float:
        return song['weeks_on_chart']


def avg_weeks_by_genre(songs: list[dict]) -> dict[str, float]:
    """Return the average weeks_on_chart for each genre.

    Args:
        songs: List of song records.

    Returns:
        A dict mapping genre name (str) to average weeks (float).

    Example:
        >>> avgs = avg_weeks_by_genre(songs)
        >>> isinstance(avgs, dict)
        True
        >>> all(isinstance(v, float) for v in avgs.values())
        True
    """

    weeks_by_genre = {}
    songs_by_genre = {}
    result = {}

    for s in songs:
        genre = s["genre"]
        if genre in weeks_by_genre:
            weeks_by_genre[genre] += s["weeks_on_chart"]
            songs_by_genre[genre] += 1
        else:
            weeks_by_genre[genre] = s["weeks_on_chart"]
            songs_by_genre[genre] = 1

    for genre in weeks_by_genre:
        result[genre] = weeks_by_genre[genre] / songs_by_genre[genre]

    return result


def most_streamed_artist(songs: list[dict]) -> str:
    """Return the name of the artist with the highest total streams_millions.

    If an artist has multiple songs, sum all their streams.

    Args:
        songs: List of song records.

    Returns:
        The artist name as a string.

    Example:
        >>> artist = most_streamed_artist(songs)
        >>> isinstance(artist, str)
        True
    """
    streams_by_artist = {}

    for song in songs:
        artist = song["artist"]

        if artist in streams_by_artist:
            streams_by_artist[artist] += song["streams_millions"]
        else:
            streams_by_artist[artist] = song["streams_millions"]

    top_artist = ""
    top_streams = None
    for artist in streams_by_artist:
        if top_streams is None or streams_by_artist[artist] > top_streams:
            top_artist = str(artist)
            top_streams = streams_by_artist[artist]

    return top_artist
    

def hits_per_year(songs: list[dict], max_position: int = 10) -> dict[int, int]:
    """Count songs with peak_position <= max_position, grouped by year.

    A "hit" is any song that reached position max_position or better (lower
    number). Only years that have at least one hit appear in the result; a
    year with no qualifying songs is omitted entirely (do not include it with
    a count of 0).

    Args:
        songs: List of song records.
        max_position: Peak position threshold (default 10).

    Returns:
        A dict mapping year (int) to hit count (int).

    Example:
        >>> hits = hits_per_year(songs, max_position=5)
        >>> all(isinstance(k, int) for k in hits.keys())
        True
    """

    hits_by_year = {}

    for song in songs:
        year = song["year"]
        position = song["peak_position"]

        if position <= max_position:
            if year in hits_by_year:
                hits_by_year[year] += 1
            else:
                hits_by_year[year] = 1

    return hits_by_year


# ── Main: print results for writeup.md ────────────────────────────────────────

if __name__ == "__main__":
    data_path = Path(__file__).parent / "data" / "songs.csv"
    songs = load_songs(data_path)

    print("=== Top 10 Songs by Streams ===")
    top = StreamsRanker().rank(songs, n=10)
    for song in top:
        print(f"  {song['title']} — {song['artist']} ({song['streams_millions']:.0f}M streams)")

    print("\n=== Top 10 Songs by Weeks on Chart ===")
    longest = LongevityRanker().rank(songs, n=10)
    for song in longest:
        print(f"  {song['title']} — {song['artist']} ({song['weeks_on_chart']} weeks)")

    print("\n=== Average Weeks on Chart by Genre ===")
    avg_weeks = avg_weeks_by_genre(songs)
    for genre, avg in sorted(avg_weeks.items(), key=lambda x: -x[1]):
        n_songs = sum(1 for s in songs if s["genre"] == genre)
        label = "song" if n_songs == 1 else "songs"
        print(f"  {genre}: {avg:.1f} weeks  ({n_songs} {label})")

    print("\n=== Most Streamed Artist ===")
    artist = most_streamed_artist(songs)
    total_streams = sum(s["streams_millions"] for s in songs if s["artist"] == artist)
    print(f"  {artist} ({total_streams:.0f}M total streams)")

    print("\n=== Top-10 Hits per Year (peak position <= 10) ===")
    hits = hits_per_year(songs, max_position=10)
    for year, count in sorted(hits.items()):
        print(f"  {year}: {count} hit(s)")
